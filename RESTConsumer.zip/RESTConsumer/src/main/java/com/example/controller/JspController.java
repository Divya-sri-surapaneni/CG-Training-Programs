package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.example.beans.Merchant;
import com.example.beans.Product;

@Controller
public class JspController {

//	@RequestMapping(value="/")
//	public String showWelcomePage(ModelMap model){
//		
//		RestTemplate restTemplate = new RestTemplate();
//		Merchant merchant = restTemplate.getForObject("http://localhost:9998/signInSuccess.json", Merchant.class);
//		System.out.println(merchant);
//		model.put("merchant", merchant);
//		return "myProfilesuccess";
//	}
	
	/*@RequestMapping(value="/")
	public String showWelcomePage(ModelMap model){
		
		RestTemplate restTemplate = new RestTemplate();
		Product product = restTemplate.getForObject("http://localhost:9998/addProductSuccess.json", Product.class);
		System.out.println(product);
		model.put("product", product);
		return "addProductSuccessPage";
	}*/
	/*@RequestMapping(value="/")
	public String showWelcomePage(ModelMap model){
		
		RestTemplate restTemplate = new RestTemplate();
		Product product = restTemplate.getForObject("http://localhost:9998/RemoveProductSuccess.json", Product.class);
		System.out.println(product);
		model.put("product", product);
		return "removeProductSuccess";
	}*/
	/*@RequestMapping(value="/")
	public String showWelcomePage(ModelMap model){
		
		RestTemplate restTemplate = new RestTemplate();
		Product product = restTemplate.getForObject("http://localhost:9998/updateProductSuccess.json", Product.class);
		System.out.println(product);
		model.put("product", product);
		return "updateProductSuccess";
	}*/
	@RequestMapping(value="/")
	public String showWelcomePage(ModelMap model){
		
		RestTemplate restTemplate = new RestTemplate();
		Merchant merchant = restTemplate.getForObject("http://localhost:9998/forgetPassword.json", Merchant.class);
		System.out.println(merchant);
		model.put("product", merchant);
		return "securityAnswer";
	}
}
