package com.cg.employee.bean;

public class Address {
	
	private String city;
	private String state;
	private int pincode;
	private String country;
	
	//generate setters

	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "EmployeeAddress [city=" + city + ", state=" + state + ", pincode=" + pincode + ", country=" + country
				+ "]";
	}

}
