package com.cg.employee.bean;

import org.springframework.beans.factory.annotation.Autowired;

public class EmployeeDetails {
	
	private int employeeId;
	private String firstName;
	private String lastName;
	private int salary;
	
	@Autowired
	private Address address;
	
	//generate setters
	
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "EmployeeDetails [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", salary=" + salary + ", address=" + address + "]";
	}
	
}
