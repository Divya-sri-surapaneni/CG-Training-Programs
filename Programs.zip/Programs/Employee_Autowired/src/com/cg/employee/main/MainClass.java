package com.cg.employee.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.employee.bean.Address;
import com.cg.employee.bean.EmployeeDetails;

public class MainClass {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("employeeBeans.xml");
		
		EmployeeDetails employeeDetails = (EmployeeDetails)context.getBean("employeeDetails");
		
		Address address = (Address)context.getBean("address");
		
		System.out.println(employeeDetails);
	}

}
