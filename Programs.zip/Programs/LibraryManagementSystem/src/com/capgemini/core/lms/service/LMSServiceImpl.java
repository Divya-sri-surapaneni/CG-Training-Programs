package com.capgemini.core.lms.service;

import java.util.List;

import com.capgemini.core.lms.bean.Book;
import com.capgemini.core.lms.dao.LMSDAO;
import com.capgemini.core.lms.dao.LMSDAOImpl;
import com.capgemini.core.lms.exceptions.LMSException;

public class LMSServiceImpl implements LMSService {

	private LMSDAO lmsDAO;
	
	public LMSServiceImpl() {
		
		lmsDAO = new LMSDAOImpl();
	}
	
	@Override
	public int addBook(Book book) throws LMSException {
		
		return lmsDAO.addBook(book) ;
	}

	@Override
	public Book getBook(int bookId) throws LMSException {
		
		return lmsDAO.getBook(bookId);
	}

	@Override
	public void updateBook(Book book) throws LMSException {
		
		lmsDAO.updateBook(book);
	}

	@Override
	public Book removeBook(int bookId) throws LMSException {
		
		return lmsDAO.removeBook(bookId);
	}

	@Override
	public List<Book> getBooks() throws LMSException {
		
		return lmsDAO.getBooks();
	}

	@Override
	public boolean isvalid(Book book) throws LMSException {
		
		return true;
	}

}
