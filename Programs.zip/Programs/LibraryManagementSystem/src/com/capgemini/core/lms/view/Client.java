package com.capgemini.core.lms.view;

import java.util.Scanner;

import com.capgemini.core.lms.bean.Book;
import com.capgemini.core.lms.dao.LMSDAO;
import com.capgemini.core.lms.dao.LMSDAOImpl;
import com.capgemini.core.lms.exceptions.LMSException;
import com.capgemini.core.lms.service.LMSService;
import com.capgemini.core.lms.service.LMSServiceImpl;

public class Client {

	private LMSService lmsService;

	public Client() {

		lmsService = new LMSServiceImpl();
	}

	public void menu() {

		System.out.println("1)Add Book");
		System.out.println("2)Get Book with id");
		System.out.println("3)Update Book");
		System.out.println("4)Remove Book");
		System.out.println("5)View All Books");
		System.out.println("0)Exit Application");

		operation();
	}
	
	public void operation() {

		Scanner console = new Scanner(System.in);

		System.out.println("Please select an option: ");
		int choice = console.nextInt();

		switch (choice) {
		case 1:      //add book
			addBook();
			break;

		case 2:
			getBook();
			break;

		case 3:
			updateBook();
			break;

		case 4:
			removeBook();
			break;

		case 5:
			allBooks();
			break;

		case 0:
			System.out.println("Thank you for using this application");
			System.exit(0);
		default:
			break;
		}
	}

	private void allBooks() {
		
		try {
			System.out.println(lmsService.getBooks());
		} catch (LMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void removeBook() {
		
		Scanner console = new Scanner(System.in);
		System.out.println("Enter id of the book to be removed");
		int id = console.nextInt();
	
		try {
			Book book = lmsService.removeBook(id);
			System.out.println(book);
		} catch (LMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void updateBook() {
		

	}

	private void getBook() {
		
		Scanner console = new Scanner(System.in);
		System.out.println("Enter id to get info");
		int id = console.nextInt();
		
		try {
			Book book = lmsService.getBook(id);
			System.out.println(book);

		} catch (LMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void addBook() {
		
		Book book = new Book();

		Scanner console = new Scanner(System.in);

		System.out.println("1)Enter Book Title: ");
		String bookTitle = console.nextLine();

		System.out.println("2)Enter Book Author: ");
		String bookAuthor = console.nextLine();

		System.out.println("3)Enter Book Price: ");
		float bookPrice = console.nextFloat();

		book.setTitle(bookTitle);
		book.setAuthor(bookAuthor);
		book.setPrice(bookPrice);


		try {
			int id = lmsService.addBook(book);
			System.out.println("The book id is: " + id);
		} catch (LMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		
		Client client = new Client();
		while(true)
			client.menu();
	}
}

//		LMSDAO lmsDAO = new LMSDAOImpl();
//
//		//add books
//		Book book1 = new Book("BasicJava", "Amit", 1200);
//		Book book2 = new Book("LearningPHP", "Ravi", 1100);
//
//		int book1Id = 0;
//		int book2Id = 0;
//
//		try {
//			book1Id = lmsDAO.addBook(book1);
//			book2Id = lmsDAO.addBook(book2);
//
//			System.out.println("Book1 Id: " + book1Id);
//			System.out.println("Book2 Id: " + book2Id);
//		} catch (LMSException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		//Get Books
//
//		try {
//			Book book3 = lmsDAO.getBook(book1Id);
//			Book book4 = lmsDAO.getBook(book2Id);
//
//			System.out.println(book3);
//			System.out.println(book4);
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//
//	}
//
//}
