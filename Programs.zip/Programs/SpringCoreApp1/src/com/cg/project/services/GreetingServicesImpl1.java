package com.cg.project.services;

import org.springframework.stereotype.Component;

//Only for developer defined classes we use @Component //creation of bean in xml is not required
@Component(value = "greetingServices")
public class GreetingServicesImpl1 implements GreetingServices {

	@Override
	public void sayHello(String name) {
		
		System.out.println("Hello " + name);	
	}

	@Override
	public void sayGoodBye(String name) {
		
		System.out.println("GoodBye " + name);	
	}

}
