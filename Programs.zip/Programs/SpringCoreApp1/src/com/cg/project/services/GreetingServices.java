package com.cg.project.services;

public interface GreetingServices {
	
	void sayHello(String name);
	
	void sayGoodBye(String name);

}
