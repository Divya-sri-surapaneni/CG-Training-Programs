package com.capgemini.core.oop.relation;

public interface Remote {
	public void powerOn();
	public void powerOff();
}
