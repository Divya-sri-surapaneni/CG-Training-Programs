package com.capgemini.core.oop.relation;

public class SamsungTvRemote implements TvRemote 
{

	@Override
	public void powerOn() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void powerOff() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeVolume() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeChannel() {
		// TODO Auto-generated method stub
		
	}

}
