package com.capgemini.core.oop.relation;

public interface ACRemote extends Remote
{
	public void changeTemp();
}
