package com.cg.scheduleManagementApp.services;

import java.util.List;

import com.cg.scheduleManagementApp.beans.SessionManagement;
import com.cg.scheduleManagementApp.exceptions.ScheduleManagementNotFound;

public interface ITrainingService {
	
	public List<SessionManagement> getAllSessions() throws ScheduleManagementNotFound;
}