package com.cg.scheduleManagementApp.exceptions;

public class ScheduleManagementNotFound extends Exception {

	public ScheduleManagementNotFound() {
	
	}

	public ScheduleManagementNotFound(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		
	}

	public ScheduleManagementNotFound(String arg0, Throwable arg1) {
		
	}

	public ScheduleManagementNotFound(String arg0) {
		
	}

	public ScheduleManagementNotFound(Throwable arg0) {
		
	}

}
