create table Customer(name varchar2(10) not null,
                   mobileNo varchar2(10) not null,
                   balance number(10,2) not null,
                   primary key(mobileNo));