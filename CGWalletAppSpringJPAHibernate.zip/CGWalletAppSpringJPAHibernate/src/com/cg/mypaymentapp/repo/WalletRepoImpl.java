package com.cg.mypaymentapp.repo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InvalidInputException;

@Component(value="walletRepo")
public class WalletRepoImpl implements WalletRepo {

	//private EntityManager entityManager;

	public WalletRepoImpl() {

		//entityManager = JPAUtil.getEntityManager();
	}


	//repo is dependent on entityManagerFactory
	@Autowired(required=true)
	private EntityManagerFactory entityManagerFactory;


	@Transactional(value=TxType.REQUIRED)
	@Override
	public boolean save(Customer customer) {

		try {	
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			
			entityManager.getTransaction().begin();
			entityManager.persist(customer);
			entityManager.flush();
			entityManager.getTransaction().commit();
			entityManager.close();
			return true;		
		} catch (Exception e) {
			return false;
		}	
	}

	@Transactional(value=TxType.REQUIRED)
	@Override
	public Customer findOne(String mobileNo) throws InvalidInputException {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Customer customer = entityManager.find(Customer.class, mobileNo);
		entityManager.flush();
		entityManager.getTransaction().commit();
		return customer;
	}

	@Transactional(value=TxType.REQUIRED)
	@Override
	public void update(Customer customer) {

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(customer);	
		entityManager.flush();
		entityManager.getTransaction().commit();
	}

}
