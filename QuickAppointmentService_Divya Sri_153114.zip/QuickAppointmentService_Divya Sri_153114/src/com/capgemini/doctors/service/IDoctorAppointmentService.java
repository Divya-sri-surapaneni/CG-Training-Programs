package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorServiceException;

public interface IDoctorAppointmentService {

	public int addDoctorAppointmentDetails( DoctorAppointment doctorappointment ) throws DoctorServiceException;

	public DoctorAppointment getDoctorAppointmentDetails( int appointmentId ) throws DoctorServiceException;

	public boolean isValid( DoctorAppointment doctorappointment ) throws DoctorServiceException;

}
