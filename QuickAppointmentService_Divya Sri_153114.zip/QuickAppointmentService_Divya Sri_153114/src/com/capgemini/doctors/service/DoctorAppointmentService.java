package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDAO;
import com.capgemini.doctors.dao.IDoctorAppointmentDAO;
import com.capgemini.doctors.exception.DoctorServiceException;

public class DoctorAppointmentService {

	private static IDoctorAppointmentDAO iDoctorAppointmentDAO;

	public DoctorAppointmentService() 
	{
		iDoctorAppointmentDAO = new DoctorAppointmentDAO();
	}


	public int addDoctorAppointmentDetails(DoctorAppointment doctorappointment) throws DoctorServiceException {

		int appointmentStatus = 0;

		if( isValid( doctorappointment ) == true)
			appointmentStatus = iDoctorAppointmentDAO.addDoctorAppointmentDetails( doctorappointment );

		return appointmentStatus;
	}


	public static DoctorAppointment getDoctorAppointmentDetails(int appointmentId) throws DoctorServiceException {

		return iDoctorAppointmentDAO.getDoctorAppointmentDetails( appointmentId );
	}


	private boolean isValid(DoctorAppointment doctorappointment) throws DoctorServiceException {

		if( doctorappointment == null)
			throw new DoctorServiceException( "Appointment instance cannot be null" );

		if( doctorappointment.getPatientName() == null || doctorappointment.getPatientName().trim().isEmpty() )
			throw new DoctorServiceException( "Patient Name Cannot be Empty" );

		if( doctorappointment.getPhoneNumber() == 0 ||  isPhoneNumberInvalid( doctorappointment.getPhoneNumber() ) )
			throw new DoctorServiceException( "Phone Number is invalid" );

		if( doctorappointment.getEmail() == null || isEmailInValid( doctorappointment.getEmail() ) )
			throw new DoctorServiceException( "Email has to be a valid email" );

		if( !(doctorappointment.getAge() > 1 && doctorappointment.getAge() <= 120) )
			throw new DoctorServiceException( "Age has to be between 1 to 120" );

		if( doctorappointment.getGender() == null || isGenderInvalid( doctorappointment.getGender() ) ) 
			throw new DoctorServiceException( "Gender can only be Male or Female" );

		if( doctorappointment.getProblemName() == null ||  doctorappointment.getProblemName().trim().isEmpty() )
			throw new DoctorServiceException( "Problem cannot be blank" );

		//if( doctorappointment.getDate() == null ||  isDateInvalid( doctorappointment.getDate() ) )
		    //throw new DoctorServiceException( "AppointmentRequest date has to be greater then current date" );

		return true;
	}

	private boolean isGenderInvalid(String gender) {
		gender = gender.toLowerCase();

		if( !gender.matches("^male$|^female$"))
			return true;	
		else
			return false;
	}


	private boolean isEmailInValid(String email) {

		if( email.matches(".+\\@.+\\..+") ) 
		{
			return false;
		}		
		else 
			return true;
	}


	private boolean isPhoneNumberInvalid(long phoneNumber) {
		if(String.valueOf(phoneNumber).matches("[1-9][0-9]{9}")) 
		{
			return false;
		}		
		else 
			return true;
	}


	public void exitApplication() {
		iDoctorAppointmentDAO.exitApplication();

	}


}
