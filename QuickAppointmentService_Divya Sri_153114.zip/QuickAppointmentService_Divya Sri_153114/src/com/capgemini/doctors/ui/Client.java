package com.capgemini.doctors.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorServiceException;
import com.capgemini.doctors.service.DoctorAppointmentService;

interface MenuOptions
{
	public static final int BOOKDOCTORAPPOINTMENT = 1;
	public static final int VIEWDOCTORAPPOINTMENTSTATUS = 2;
	public static final int EXITAPPLICATION = 3;
}

public class Client implements MenuOptions {

	private DoctorAppointmentService doctorAppointmentService;

	public Client() {

		doctorAppointmentService = new DoctorAppointmentService();
	}

	public void menu() {

		Scanner console = new Scanner( System.in );

		System.out.println("1) Book Doctor Appointment"); 
		System.out.println("2) View Doctor Appointment");
		System.out.println("3) Exit");

		System.out.print("\nEnter Your Choice: ");
		int choice = console.nextInt();

		operation( choice );
	}

	public void operation( int choice )
	{
		switch ( choice ) 
		{
		case BOOKDOCTORAPPOINTMENT: addDoctorAppointmentDetails(); break;
		case VIEWDOCTORAPPOINTMENTSTATUS: getAppointmentDetails(); break;
		case EXITAPPLICATION: exitApplication(); break;

		default:
			break;
		}
	}

	private void addDoctorAppointmentDetails() {

		//Taking details from the User

		Scanner console = new Scanner( System.in );

		System.out.print("\n\nEnter Name of the Patient: ");
		String patientName = console.nextLine();

		System.out.print("Enter Phone Number: ");
		long phoneNumber = console.nextLong();

		System.out.print("Enter Email: ");
		String email = console.next();

		System.out.print("Enter Age: ");
		int age = console.nextInt();

		System.out.print("Enter Gender: ");
		String gender = console.next();

		System.out.print("Enter Problem name: ");
		String problemName = console.next();
		
		System.out.print("Enter Appointment Date (dd/mm/yyyy): ");
		String appointmentRequestedDate = console.next();


		//Instantiating and initializing The Bean

		DoctorAppointment doctorappointment = new DoctorAppointment();

		doctorappointment.setPatientName( patientName );
		doctorappointment.setPhoneNumber( phoneNumber );
		doctorappointment.setEmail( email );
		doctorappointment.setAge( age );
		doctorappointment.setGender( gender );
		doctorappointment.setProblemName( problemName );
		doctorappointment.setAppointmentDate( getDateFromString( appointmentRequestedDate ) );

		//sending appointment request to service

		try 
		{
			int appointmentId = doctorAppointmentService.addDoctorAppointmentDetails( doctorappointment );

			System.out.println("\n\nYour Doctor Appointment has been successfully registered, your appointment ID is : "+ appointmentId  + "\n\n");

		}
		catch (DoctorServiceException e) 
		{
			//e.printStackTrace();
			System.out.println("Something went wrong. Reason: " + e.getMessage() );
		}
		catch(Exception e)
		{
			//e.printStackTrace();
			System.out.println("Something went wrong. Please try again after some time.");
		}
	}

	
	
	private void getAppointmentDetails() {

		Scanner console = new Scanner( System.in );

		System.out.print("\n\nEnter the appointment Id: ");
		int appointmentId = console.nextInt();

		try 
		{
			DoctorAppointment doctorappointment = 
					DoctorAppointmentService.getDoctorAppointmentDetails( appointmentId );

			System.out.println("\n\nPatient Name: " + doctorappointment.getPatientName() );
			System.out.println("Appointment Status: " + doctorappointment.getAppointmentStatus() );

			if( doctorappointment.getAppointmentStatus().equalsIgnoreCase("DISAPPROVED") )
			{
				System.out.println("Doctor Name: ");
				System.out.println("Appointment Date: \n\n");
			}
			else
			{
				System.out.println("Doctor Name: " + doctorappointment.getDoctorName() );


				System.out.println("\n\nAppointment Date and time, along with doctor�s phone number will be shared shortly with you.");
			}

		} 
		catch (DoctorServiceException e) 
		{
			//e.printStackTrace();
			System.out.println("Something went wrong. Reason: " + e.getMessage() );
		}
		catch(Exception e)
		{
			//e.printStackTrace();
			System.out.println("Something went wrong. Please try again after some time.");
		}
	}

	public Date getDateFromString( String dateInString )
	{
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		LocalDate localDate = LocalDate.parse(dateInString , formatter);

		java.util.Date date = java.sql.Date.valueOf( localDate );

		return date;
	}

	private void exitApplication() {
		System.out.println("Thank you for using out Appointment Service Application");
		doctorAppointmentService.exitApplication();
		System.exit( 0 );
	}



	public static void main(String[] args) {

		Client client = new Client();

		while(true)
			client.menu();
	}
}
