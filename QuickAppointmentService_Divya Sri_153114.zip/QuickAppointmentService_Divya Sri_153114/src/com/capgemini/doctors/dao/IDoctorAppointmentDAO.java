package com.capgemini.doctors.dao;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorServiceException;

public interface IDoctorAppointmentDAO {
	
	public int addDoctorAppointmentDetails( DoctorAppointment doctorappointment ) throws DoctorServiceException;
	
	public DoctorAppointment getDoctorAppointmentDetails( int appointmentId ) throws DoctorServiceException;

	public void exitApplication();
	
}
