package com.capgemini.doctors.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorServiceException;

public class DoctorAppointmentDAO implements IDoctorAppointmentDAO {

	//private List<DoctorAppointment> appointments = new ArrayList<Appointment>();
	private Map<Integer, DoctorAppointment> patients  = new HashMap<Integer, DoctorAppointment>();



	private Map<String, String> doctors  = new HashMap<String, String>();{
		doctors.put("Heart", "Dr. Brijesh Kumar");
		doctors.put("Gynecology", "Dr. Sharda Singh");
		doctors.put("Diabetes", "Dr. Heena Khan");
		doctors.put("ENT", "Dr. Paras Mal");
		doctors.put("Bone", "Dr. Renuka Kher");
		doctors.put("Dermatology", "Dr. Kanika Kapoor");

	}

	public int generateAppointmentId() {

		double rndDouble = Math.random();
		return (int)(rndDouble * 10000);
	}

	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorappointment) throws DoctorServiceException {


		doctorappointment.setAppointmentId(generateAppointmentId());
		String problem  = doctorappointment.getProblemName();

		if( doctors.get(problem) != null )
		{

			doctorappointment.setAppointmentStatus("Approved");
			doctorappointment.setDoctorName( doctors.get(problem) );
		}

		//patients.put(doctorappointment.getAppointmentId(),  )

		patients.put( doctorappointment.getAppointmentId(), doctorappointment );

		return doctorappointment.getAppointmentId();
	}


	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) throws DoctorServiceException {

		DoctorAppointment doctorappointment =  patients.get(appointmentId);

		if(doctorappointment.getDoctorName() == null) throw new DoctorServiceException("There is no doctor available for your problem");
		return doctorappointment;
	}

	@Override
	public void exitApplication() {
		// TODO Auto-generated method stub

	}

}
