package com.capgemini.doctors.exception;

public class DoctorServiceException extends Exception {

	public DoctorServiceException() {
		super();
		
	}

	public DoctorServiceException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		
	}

	public DoctorServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	public DoctorServiceException(String arg0) {
		super(arg0);
		
	}

	public DoctorServiceException(Throwable arg0) {
		super(arg0);
		
	}
	
	

}
