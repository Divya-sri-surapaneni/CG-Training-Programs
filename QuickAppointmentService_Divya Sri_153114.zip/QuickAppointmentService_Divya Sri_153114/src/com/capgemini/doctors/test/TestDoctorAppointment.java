package com.capgemini.doctors.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorServiceException;
import com.capgemini.doctors.service.DoctorAppointmentService;

public class TestDoctorAppointment {

	private static DoctorAppointmentService doctorappointmentservice;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		doctorappointmentservice = new DoctorAppointmentService();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {

		doctorappointmentservice = null;
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test1() throws DoctorServiceException {
		DoctorAppointment doctorappointment = new DoctorAppointment();

		doctorappointment.setPatientName("Eric");
		doctorappointment.setPhoneNumber(9898989898L);
		doctorappointment.setEmail("eric@gmail.com");
		doctorappointment.setGender("Male");
		doctorappointment.setAge(32);
		doctorappointment.setProblemName("Heart");
		doctorappointment.setAppointmentDate( getDateFromString("04-12-2018") );

		int appointmentId = doctorappointmentservice.addDoctorAppointmentDetails( doctorappointment );

		assertTrue( appointmentId > 0 );
	}

	@Test
	public void test2() throws DoctorServiceException {

		DoctorAppointment doctorappointment = new DoctorAppointment();

		doctorappointment.setPatientName("Eric");
		doctorappointment.setPhoneNumber(9898989898L);
		doctorappointment.setEmail("eric@gmail.com");
		doctorappointment.setGender("Male");
		doctorappointment.setAge(32);
		doctorappointment.setProblemName("Heart");
		doctorappointment.setAppointmentDate( getDateFromString("04-12-2018") );

		int appointmentId = doctorappointmentservice.addDoctorAppointmentDetails( doctorappointment );

		DoctorAppointment appointment2
		= doctorappointmentservice.getDoctorAppointmentDetails(appointmentId);

		assertNotEquals(null, appointment2);
	}

	public Date getDateFromString( String dateInString )
	{
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		LocalDate localDate = LocalDate.parse(dateInString , formatter);

		java.util.Date date = java.sql.Date.valueOf( localDate );

		return date;
	}


}
