package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Registration {

	@FindBy(name="fname")
	 public WebElement fname;
	
	@FindBy(name="lname")
	public WebElement lname;
		
	@FindBy(how=How.XPATH,xpath="/html/body/centre/table/tbody/tr[3]/td[2]/input[1]")
	public WebElement gender1;
	
	@FindBy(how=How.XPATH,xpath="/html/body/centre/table/tbody/tr[4]/td[2]/input[1]")
	public WebElement vehicle;
	
	@FindBy(how=How.XPATH,xpath="/html/body/centre/table/tbody/tr[4]/td[2]/input[2]")
	public WebElement vehicle1;
	
	@FindBy(name="email")
	public WebElement email;
	
	@FindBy(name="contact")
	public WebElement contact;
	
	@FindBy(name="address")
	public WebElement address;
	
	@FindBy(name="city")
	public WebElement city;
	
	@FindBy(how=How.NAME,name ="state")
	public WebElement state;
	
	@FindBy(how=How.XPATH,xpath="/html/body/centre/table/tbody/tr[9]/td[2]/select/option[3]")
	public WebElement state1;
	
	@FindBy(name="submit")
	public WebElement submit;

	public String getFname() {
		return fname.getAttribute("value");
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public String getLname() {
		return lname.getAttribute("value");
	}

	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}

	
	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getContact() {
		return contact.getAttribute("value");
	}

	public void setContact(String contact) {
		this.contact.sendKeys(contact);
	}

	public String getAddress() {
		return address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public String getCity() {
		return city.getAttribute("value");
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public String getState() {
		return state.getAttribute("value");
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public String getState1() {
		return state1.getAttribute("value");
	}

	public void setState1(String state1) {
		this.state1.sendKeys(state1);
	}

	public void clickSubmit() {
		submit.click();
	}

	public void clickElement() {
		gender1.click();
		
	}
	public void clickVehicle() {
		vehicle.click();
	}
	public void clickVehicle1() {
		vehicle1.click();
	}
}