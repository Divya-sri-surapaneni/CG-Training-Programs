package com.cg.project.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.NextPage;
import com.cg.project.beans.Registration;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {
	
	
	private WebDriver driver;
	Registration registration;
	NextPage nextpage;
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Softwares\\chromedriver.exe");		
	 }
	@Given("^User is on registration Page$")
	public void user_is_on_registration_Page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("D:\\alekhya\\CUCUMBER\\RegistrationSample\\htmlPages\\Index.html");
	    registration = PageFactory.initElements(driver, Registration.class);
	 
	    }

	@When("^User enters valid details$")
	public void user_enters_valid_details() throws Throwable {
			registration.setFname("Alekhya");
			registration.setLname("reddy");
			registration.clickElement();
			registration.clickVehicle();
			registration.clickVehicle1();
			registration.setEmail("allu@gmail.com");
			registration.setContact("9876543210");;
			registration.setAddress("1 kumbhangar");
			registration.setCity("chattisgarh");
			registration.setState(registration.getState1());
			
			registration.submit.click();
			Alert jsAlert = driver.switchTo().alert();
			if(jsAlert.getText().equals("validated"))
			{
				Thread.sleep(1000);
				jsAlert.accept();
				driver.navigate().to("D:\\alekhya\\CUCUMBER\\RegistrationSample\\htmlPages\\nextPage.html");
				nextpage = PageFactory.initElements(driver, NextPage.class);
			}
			else
			{
				
			}
			nextpage.setPname("PARAM");
			nextpage.setPdetails("J2EE project");
			nextpage.setClient("HP");
			nextpage.setSize("7");
			nextpage.register.click();
	   }

	@Then("^Registration successful message is displayed$")
	public void registration_successful_message_is_displayed() throws Throwable {
		
	   }
	@When("^User enters Invalid details$")
	public void user_enters_Invalid_details() throws Throwable {
		registration.setFname("Alekhya");
		registration.setLname("reddy");
		registration.clickElement();
		registration.clickVehicle();
		registration.clickVehicle1();
		registration.setEmail("allu@gmail.com");
		registration.setContact("9876543");;
		registration.setAddress("1 kumbhangar");
		registration.setCity("chattisgarh");
		registration.setState(registration.getState1());
		
		registration.submit.click();
		Alert jsAlert = driver.switchTo().alert();
		if(jsAlert.getText().equals("validated"))
		{
			Thread.sleep(1000);
			jsAlert.accept();
			driver.navigate().to("D:\\\\Users\\\\adm-ig-hwdlab1c\\\\Downloads\\\\selenium-casestudy1-master\\\\Testing6CASE1\\nextPage.html");
			nextpage = PageFactory.initElements(driver, NextPage.class);
		}
		else
		{
			
		}
//		nextpage.setPname("PARAM");
//		nextpage.setPdetails("J2EE project");
//		nextpage.setClient("HP");
//		nextpage.setSize("7");
//		nextpage.register.click();
	}

	@Then("^Registration Unsuccessful message is displayed$")
	public void registration_Unsuccessful_message_is_displayed() throws Throwable {
		String actualErrorMessage="You have entered an incorrect contact number!";
		String expectedErrorMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}
}