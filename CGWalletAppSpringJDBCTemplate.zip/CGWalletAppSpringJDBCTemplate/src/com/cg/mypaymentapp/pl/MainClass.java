package com.cg.mypaymentapp.pl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.mypaymentapp.service.WalletService;

public class MainClass {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("projectBeans.xml");
		
		WalletService walletService = (WalletService)context.getBean("walletService");
	}

}
