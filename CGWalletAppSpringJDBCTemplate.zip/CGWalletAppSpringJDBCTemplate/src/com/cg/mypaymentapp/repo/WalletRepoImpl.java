package com.cg.mypaymentapp.repo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.exceptions.InvalidInputException;

@Component(value="walletRepo")
public class WalletRepoImpl implements WalletRepo {
	
	//repo is dependent on jdbcTemplate
	@Autowired
	private JdbcTemplate jdbcTemplate;

	private Map<String, Customer> data; 

	public WalletRepoImpl() {

		data = new HashMap<String, Customer>();
	}

	Customer customer = new Customer();
	Wallet wallet = new Wallet();

	@Override
	public boolean save(Customer customer) throws InvalidInputException {
		
		return false;
	}
	@Override
	public Customer findOne(String mobileNo) throws InvalidInputException {
		
		return null;
	}
	@Override
	public void update(String mobileNo) {
		
		
	}
	
}