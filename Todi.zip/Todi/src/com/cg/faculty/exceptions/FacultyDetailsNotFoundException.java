package com.cg.faculty.exceptions;

public class FacultyDetailsNotFoundException extends Exception {

	public FacultyDetailsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FacultyDetailsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public FacultyDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FacultyDetailsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FacultyDetailsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	

}